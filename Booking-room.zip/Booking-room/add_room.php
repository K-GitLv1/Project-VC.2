<?php
// เชื่อมต่อฐานข้อมูล
include 'db/db_connection.php';

// ถ้าฟอร์มถูกส่ง
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $room_name = isset($_POST['room_name']) ? $_POST['room_name'] : null;

    // ตรวจสอบว่ากรอกชื่อห้องแล้วหรือยัง
    if (empty($room_name)) {
        echo "กรุณากรอกชื่อห้อง.";
        exit;
    }

    $description = isset($_POST['description']) ? $_POST['description'] : null;
    $location = isset($_POST['location']) ? $_POST['location'] : null;
    $room_number = isset($_POST['room_number']) ? $_POST['room_number'] : null;
    $capacity = isset($_POST['capacity']) ? intval($_POST['capacity']) : null;

    // อัปโหลดไฟล์
    $target_dir = "uploads/";
    $image_paths = []; // เก็บไฟล์หลายไฟล์

    if (!empty($_FILES["image"]["name"][0])) {
        $uploadOk = 1;
        $imageFileTypes = ['jpg', 'jpeg', 'png', 'webp'];

        // ตรวจสอบแต่ละไฟล์
        for ($i = 0; $i < count($_FILES['image']['name']); $i++) {
            $image_name = basename($_FILES["image"]["name"][$i]);
            $target_file = $target_dir . time() . "_" . $image_name;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            // ตรวจสอบว่าเป็นรูปภาพหรือไม่
            $check = getimagesize($_FILES["image"]["tmp_name"][$i]);
            if ($check !== false && in_array($imageFileType, $imageFileTypes)) {
                if (move_uploaded_file($_FILES["image"]["tmp_name"][$i], $target_file)) {
                    $image_paths[] = $target_file; // เก็บชื่อไฟล์ที่อัปโหลด
                } else {
                    echo "เกิดข้อผิดพลาดในการอัปโหลดไฟล์.";
                    $uploadOk = 0;
                    break;
                }
            } else {
                echo "ไฟล์ที่อัปโหลดไม่ถูกต้อง.";
                $uploadOk = 0;
                break;
            }
        }
    }

    // แปลงเป็น JSON หากมีหลายไฟล์
    $image_paths_json = json_encode($image_paths);

    // เพิ่มข้อมูลในฐานข้อมูล
    $sql = "INSERT INTO rooms (room_name, description, location, room_number, capacity, image, is_visible, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, 1, NOW())";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssds",
        $room_name,
        $description,
        $location,
        $room_number,
        $capacity,
        $image_paths_json
    );

    if ($stmt->execute()) {
        header("Location: add_room.php?status=success");
    } else {
        echo "เกิดข้อผิดพลาด: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มห้องประชุม</title>
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/addr.css">
    <link rel="stylesheet" href="css/bk.css">
    <script src="js/bk.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100..900&display=swap" rel="stylesheet">
</head>
<body>
<?php 
    include 'check_login.php';
    include 'footer.php';
?>

<?php if (isset($_GET['status'])): ?>
    <script>
        window.onload = function() {
            showToast('<?php echo $_GET['status']; ?>');
        }

        function showToast(status) {
            var toast = document.createElement('div');
            toast.classList.add('toast');
            toast.innerHTML = (status === 'success') ? 'เพิ่มห้องประชุมเรียบร้อย!' : 'เกิดข้อผิดพลาดในการเพิ่มห้องประชุม!';
            document.body.appendChild(toast);

            // หายไปหลังจาก 3 วินาที
            setTimeout(function() {
                toast.classList.add('fade-out');
                setTimeout(function() {
                    toast.remove();
                }, 500);
            }, 3000);
        }
    </script>
<?php endif; ?>

<style>
/* Style สำหรับ toast */
.toast {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    opacity: 1;
    z-index: 9999;
    transition: opacity 0.5s ease;
}

/* การทำให้ toast หายไป */
.toast.fade-out {
    opacity: 0;
}

body {
    padding-bottom: 100px;
}
#imageFileName {
    color: black;
}
#imagePreviews {
    display: flex;
    flex-wrap: wrap;
    gap: 10px; /* เพิ่มช่องว่างระหว่างภาพ */
}

#imagePreviews div {
    display: inline-block;
    text-align: center;
}

#imagePreviews img {
    max-width: 200px;
    height: auto;
}

</style>

<div class="container">
    <h2>เพิ่มห้องประชุม</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <label for="room_name">ชื่อห้อง:</label>
        <input type="text" id="room_name" name="room_name" required><br><br>

        <label for="description">รายละเอียด:</label><br>
        <textarea id="description" name="description" rows="4"></textarea><br><br>

        <label for="location">อาคาร/สถานที่:</label>
        <input type="text" id="location" name="location"><br><br>

        <label for="room_number">เลขที่ห้อง:</label>
        <input type="text" id="room_number" name="room_number"><br><br>

        <label for="capacity">จำนวนที่นั่ง:</label>
        <input type="number" id="capacity" name="capacity"><br><br>

        <label for="image">รูปภาพ:</label>
        <input type="file" id="image" name="image[]" accept=".jpg,.jpeg,.png,.webp" multiple onchange="previewImages();"><br><br>

        <div id="imagePreviewContainer" style="display: none;">
            <div id="imagePreviews"></div>
        </div>

        <button type="submit">บันทึก</button>
    </form>
</div>

<script>
// JavaScript function to preview the selected images and show the filenames
function previewImages() {
    const fileInput = document.getElementById("image");
    const files = fileInput.files;
    const imagePreviews = document.getElementById("imagePreviews");
    imagePreviews.innerHTML = ""; // Clear previous previews

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();

        reader.onload = function(e) {
            const previewDiv = document.createElement('div');
            const previewImage = document.createElement('img');
            previewImage.src = e.target.result;
            previewImage.style.maxWidth = "200px";
            previewDiv.appendChild(previewImage);

            const fileName = document.createElement('p');
            fileName.textContent = file.name; // Show file name
            previewDiv.appendChild(fileName);

            imagePreviews.appendChild(previewDiv);
        };

        reader.readAsDataURL(file); // Read file as data URL
    }

    document.getElementById("imagePreviewContainer").style.display = "block"; // Show the preview container
}
</script>

</body>
</html>
