<?php
// รวมไฟล์เชื่อมต่อฐานข้อมูล
include './db_connection.php'; // เปลี่ยนเป็นชื่อไฟล์ของคุณถ้าไฟล์ชื่อแตกต่างจากนี้

// คำสั่ง SQL ดึงข้อมูลการจอง
$sql = "SELECT id, title, start, end FROM events";
$result = $conn->query($sql);

// สร้างอาร์เรย์เพื่อเก็บข้อมูลที่ดึงออกมา
$events = array();

if ($result->num_rows > 0) {
    // ดึงข้อมูลแต่ละแถว
    while($row = $result->fetch_assoc()) {
        $events[] = array(
            'id' => $row['id'],
            'title' => $row['title'],
            'start' => $row['start'],
            'end' => $row['end']
        );
    }
}

// ปิดการเชื่อมต่อ
$conn->close();

// ส่งข้อมูลเป็น JSON
echo json_encode($events);
?>
