-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2025 at 05:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bkx2`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_name` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `room_number` varchar(50) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_visible` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_name`, `color`, `description`, `location`, `room_number`, `capacity`, `image`, `created_at`, `is_visible`) VALUES
(25, 'testttttttttttttttttttttttttttttttttttttttt', NULL, 'testttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttt', 'testttttttttttttttttttttttttttttttttttttttt', '123', 123, '[\"uploads\\/1737994047_large.jpg\"]', '2025-01-25 12:17:53', 1),
(26, 'testttttttttttttttttttttttttttttttttttttttt', NULL, '#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n#imageFileName {\r\n    color: black; /* เปลี่ยนสีเป็นสีดำ */\r\n}\r\n', '#imageFileName {     color: black; /* เปลี่ยนสีเป็นสีดำ */ }', '123', 123, '[\"uploads\\/1737994795_11.jpg\"]', '2025-01-25 12:19:25', 1),
(27, 'testttttttttttttttttttttttttttttttttttttttt', NULL, 'testttttttttttttttttttttttttttttttttttttttttestttttttttttttttttttttttttttttttttttttttt', 'testttttttttttttttttttttttttttttttttttttttt', '123', 123, 'uploads/1737977796_11.jpg', '2025-01-27 11:36:36', 1),
(28, 'test', NULL, '', '', '', 0, NULL, '2025-01-27 11:55:20', 1),
(29, 'test', NULL, 'test', 'test', '123', 123, NULL, '2025-01-27 12:06:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'test', '$2y$10$woQghDEDNIMqoKXX6P84gOia3Yr0MJA0epa3ZB/0/U2J9Cyxa6usa', '2024-10-27 16:16:16'),
(2, 'test2', '$2y$10$PRHUMrFheweD57Sa.anxm.LrZe0a48FuvzqrG/H1PLvZejeFUlT9W', '2024-10-27 16:20:32'),
(3, 'test3', '$2y$10$wLWa2wla2OrBOLFPRrNjGOjAENqwgIdgZi1UeoD1WyKqu/eL9tsCa', '2024-10-30 13:55:20'),
(6, 'admin', '$2y$10$Rl5jn/4maFi5kq.rrztafew.bQCAWrOXLQaBj1vwusnJo9P8vslNK', '2024-12-06 10:42:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_3` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
