document.addEventListener("DOMContentLoaded", function () {
  const calendarEl = document.getElementById("calendar");

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "dayGridMonth",
    headerToolbar: {
      left: "prev,next today", // ปุ่มย้อนกลับ ถัดไป และปุ่ม "วันนี้"
      center: "title", // ชื่อเดือนที่แสดงตรงกลาง
      right: "dayGridMonth,timeGridWeek,timeGridDay" // เปลี่ยนมุมมอง
    },
    events: {
      url: "events.php", // ดึงข้อมูลการจองจาก PHP
      failure: function () {
        alert("ไม่สามารถโหลดข้อมูลการจองได้!");
      }
    }
  });

  calendar.render();
});
