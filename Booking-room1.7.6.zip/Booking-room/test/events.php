<?php
header('Content-Type: application/json');

// เชื่อมต่อฐานข้อมูล
$host = "localhost";
$dbname = "bkx2";
$username = "root"; // แก้เป็นชื่อผู้ใช้ของคุณ
$password = ""; // แก้เป็นรหัสผ่านของคุณ

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ดึงข้อมูลจากฐานข้อมูล
    $stmt = $pdo->prepare("
        SELECT 
            bookings.id, 
            rooms.name AS room_name, 
            bookings.start_time AS start, 
            bookings.end_time AS end, 
            CONCAT('จองห้อง: ', rooms.name) AS title
        FROM bookings
        LEFT JOIN rooms ON bookings.room_id = rooms.id
    ");
    $stmt->execute();

    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($events);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
