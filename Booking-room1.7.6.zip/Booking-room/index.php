<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>หน้าหลัก</title>
    <link rel="stylesheet" href="css/theme.css">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100..900&display=swap" rel="stylesheet">
    


    <script src=
    "https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/6.1.4/index.global.js"
    ></script>


<!-- FullCalendar JS -->
<!-- <script src="./fullcalendar/dist/index.global.min.js"></script> -->

    <style>
      body {
    padding-bottom: 100px;
}
        /* Calendar container */
        #calendar {
            margin-top: 180px; /* ระยะห่างจาก header */
            width: 120%; /* ตั้งความกว้างให้เล็กลง */
            max-width: 1200px; /* ตั้งความกว้างสูงสุด */
            height: 1000px; /* กำหนดความสูง */
            margin-left: auto; /* จัดให้อยู่กลาง */
            margin-right: auto; /* จัดให้อยู่กลาง */
            
        }
        
        /* สีของกิจกรรมที่ยังไม่ยืนยัน */
    .fc-event.unconfirmed {
      background-color:rgb(255, 66, 66); /* สีแดง */
      border-color:rgb(255, 0, 0);
      white-space: nowrap; /* ป้องกันการตัดขึ้นบรรทัดใหม่ */
      overflow: visible; /* ให้แสดงข้อความเต็ม */
      text-overflow: clip; /* ป้องกันข้อความหายไป */
      
    }

    /* สีของกิจกรรมที่ยืนยันแล้ว */
    .fc-event.confirmed {
      background-color:rgb(0, 212, 18); /* สีม่วง */
      border-color:rgb(255, 255, 255);
      white-space: nowrap; /* ป้องกันการตัดขึ้นบรรทัดใหม่ */
      overflow: visible; /* ให้แสดงข้อความเต็ม */
      text-overflow: clip; /* ป้องกันข้อความหายไป */
    }


    </style>
</head>
<body>
<?php 
    include 'check_login.php';
    // include 'footer.php';
?>
 <!-- Calendar Section -->
 <div id="calendar"></div>


 <script>
document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');

  var calendar = new FullCalendar.Calendar(calendarEl, {
    locale: 'th',
    selectable: true,
    businessHours: true,
    dayMaxEvents: true, // allow "more" link when too many events

    // ดึงข้อมูลกิจกรรมจาก events.php
    events: function(info, successCallback, failureCallback) {
      fetch('events.php')
        .then(response => response.json())
        .then(data => {
          // ส่งข้อมูลกิจกรรมไปแสดงในปฏิทิน
          successCallback(data);
        })
        .catch(error => {
          failureCallback(error); // ถ้ามีข้อผิดพลาด
        });
    }
  });

  calendar.render();
});

</script>


</body>
</html>
