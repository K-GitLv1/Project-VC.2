<?php
include 'db/db_connection.php'; // เชื่อมต่อกับฐานข้อมูล

$sql = "SELECT * FROM bookings"; // ดึงข้อมูลทั้งหมด
$result = $conn->query($sql);

$events = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // แปลงเวลาให้อยู่ในรูปแบบ HH:mm
        $start_time = date("H:i", strtotime($row['start_time']));
        $end_time = date("H:i", strtotime($row['end_time']));

        // แสดงช่วงเวลาและหัวข้อการประชุม
        $title = "$start_time - $end_time: " . $row['purpose'];  // แสดงเวลาพร้อมหัวข้อ

        $events[] = array(
            'title' => $title,
            'start' => $row['start_date'] . 'T' . $row['start_time'],
            'end' => $row['end_date'] . 'T' . $row['end_time'],
            'description' => $row['other_details'],
            'className' => $row['is_confirmed'] == 1 ? 'confirmed' : 'unconfirmed'
        );
    }
}

// ส่งข้อมูลในรูปแบบ JSON
echo json_encode($events);

$conn->close();
?>
