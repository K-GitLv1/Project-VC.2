<?php
// เชื่อมต่อกับฐานข้อมูล
include 'db/db_connection.php'; 
include 'check_admin.php';
// จำนวนการจองตามวัน (วันนี้)
$query_today = "SELECT COUNT(*) AS bookings_today FROM bookings WHERE DATE(start_date) = CURDATE()";
$result_today = mysqli_query($conn, $query_today);
if ($result_today) {
    $row_today = mysqli_fetch_assoc($result_today);
    $bookings_today = $row_today['bookings_today'];
} else {
    $bookings_today = 0; // ถ้าดึงข้อมูลไม่ได้ กำหนดเป็น 0
}

// จำนวนการจองตามสัปดาห์ (สัปดาห์นี้)
$query_week = "SELECT COUNT(*) AS bookings_week FROM bookings WHERE WEEK(start_date) = WEEK(CURDATE())";
$result_week = mysqli_query($conn, $query_week);
if ($result_week) {
    $row_week = mysqli_fetch_assoc($result_week);
    $bookings_week = $row_week['bookings_week'];
} else {
    $bookings_week = 0; // ถ้าดึงข้อมูลไม่ได้ กำหนดเป็น 0
}

// จำนวนการจองตามเดือน (เดือนนี้)
$query_month = "SELECT COUNT(*) AS bookings_month FROM bookings WHERE MONTH(start_date) = MONTH(CURDATE())";
$result_month = mysqli_query($conn, $query_month);
if ($result_month) {
    $row_month = mysqli_fetch_assoc($result_month);
    $bookings_month = $row_month['bookings_month'];
} else {
    $bookings_month = 0; // ถ้าดึงข้อมูลไม่ได้ กำหนดเป็น 0
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แดชบอร์ด - ระบบจองห้องประชุม</title>
    <link rel="stylesheet" href="css/theme.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100..900&display=swap" rel="stylesheet">
    <!-- เชื่อมโยง Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            margin-top: 120px;
            padding-bottom: 100px;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            margin: 15px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: inline-block;
            width: 30%;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card h3 {
            margin-top: 0;
        }
        .card-header {
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 10px;
        }
        canvas {
            max-width: 100%;
        }
        .row {
            display: flex;
            justify-content: space-between;
        }
        .row .card {
            width: 30%;
        }

        /* เพิ่มสีสำหรับแต่ละช่วงเวลา */
        .card.today {
            background-color: #FFEB3B; /* สีเหลือง */
            border-left: 5px solid #FF9800; /* สีส้ม */
        }
        .card.week {
            background-color: #FF9800; /* สีส้ม */
            border-left: 5px solid #FF5722; /* สีแดง */
        }
        .card.month {
            background-color: #F44336; /* สีแดง */
            border-left: 5px solid #D32F2F; /* สีเข้ม */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>แดชบอร์ด</h1>

        <!-- แสดงข้อมูลในรูปแบบของ Card -->
        <div class="row">
            <div class="card today">
                <div class="card-header">การจองห้องประชุมวันนี้</div>
                <h3><?php echo $bookings_today; ?> ครั้ง</h3>
            </div>

            <div class="card week">
                <div class="card-header">การจองห้องประชุมสัปดาห์นี้</div>
                <h3><?php echo $bookings_week; ?> ครั้ง</h3>
            </div>

            <div class="card month">
                <div class="card-header">การจองห้องประชุมเดือนนี้</div>
                <h3><?php echo $bookings_month; ?> ครั้ง</h3>
            </div>
        </div>

        <!-- กราฟการจองห้องประชุมตามวัน -->
        <div class="card">
            <h3>จำนวนการจองห้องประชุมตามวัน</h3>
            <canvas id="bookingsChart"></canvas>
        </div>
    </div>

    <script>
        // ดึงข้อมูลจาก PHP ไปใช้ใน JavaScript
        const datesData = <?php echo json_encode($dates_data); ?>;

        // สร้างกราฟ
        const ctx = document.getElementById('bookingsChart').getContext('2d');
        const bookingsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: datesData.map(data => data.booking_date),
                datasets: [{
                    label: 'จำนวนการจองห้องประชุมต่อวัน',
                    data: datesData.map(data => data.bookings_per_day),
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true,
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'วันที่'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'จำนวนการจอง'
                        },
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
