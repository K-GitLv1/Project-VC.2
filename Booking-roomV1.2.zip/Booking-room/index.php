<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>หน้าหลัก</title>
    <link rel="stylesheet" href="css/theme.css">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100..900&display=swap" rel="stylesheet">
    
    <!-- FullCalendar CSS
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/6.1.4/index.global.min.css" rel="stylesheet" />

    FullCalendar JS
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/6.1.4/index.global.min.js"></script> -->

    <!-- FullCalendar CSS -->
<link href="./fullcalendar/dist/index.global.min.css" rel="stylesheet" />

<!-- FullCalendar JS -->
<script src="./fullcalendar/dist/index.global.min.js"></script>

    <style>
        /* Calendar container */
        #calendar {
            margin-top: 180px; /* ระยะห่างจาก header */
            width: 120%; /* ตั้งความกว้างให้เล็กลง */
            max-width: 1000px; /* ตั้งความกว้างสูงสุด */
            height: 600px; /* กำหนดความสูง */
            margin-left: auto; /* จัดให้อยู่กลาง */
            margin-right: auto; /* จัดให้อยู่กลาง */
        }







    </style>
</head>
<body>
<?php 
    include 'check_login.php';
    include 'footer.php';
?>
 <!-- Calendar Section -->
 <div id="calendar"></div>

<!-- Footer -->
<footer>
    <p>ProjectVC.2 2024 | E-Booking System</p>
</footer>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const calendarEl = document.getElementById("calendar");

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        headerToolbar: {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,timeGridDay"
        },
        events: "events.php", // ดึงข้อมูลจาก events.php
        locale: "th",
        eventColor: "#3788d8",
        eventTextColor: "#fff"
    });

    calendar.render();
});

</script>

</body>
</html>
