<?php
header('Content-Type: application/json');
require 'db/db_connect.php'; // เชื่อมต่อฐานข้อมูล

$sql = "SELECT bookings.id, rooms.room_name, bookings.start_time, bookings.end_time
        FROM bookings
        JOIN rooms ON bookings.room_id = rooms.id";

$result = $conn->query($sql);
$events = [];

while ($row = $result->fetch_assoc()) {
    $events[] = [
        'id' => $row['id'],
        'title' => $row['room_name'],
        'start' => $row['start_time'],
        'end' => $row['end_time']
    ];
}

echo json_encode($events);
?>
