<?php
include 'db/db_connection.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    die("กรุณาเข้าสู่ระบบก่อนทำการจอง");
}

$user_id = $_SESSION['user_id'];
$room_id = $_POST['room_id'];
$booking_date = $_POST['booking_date'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];

// ตรวจสอบการจองซ้อน
$check_sql = "SELECT * FROM bookings WHERE room_id = ? AND booking_date = ? AND 
              ((start_time < ? AND end_time > ?) OR (start_time < ? AND end_time > ?))";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param("isssss", $room_id, $booking_date, $end_time, $end_time, $start_time, $start_time);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    die("ห้องนี้ถูกจองในช่วงเวลาที่เลือกแล้ว กรุณาเลือกเวลาอื่น");
}

// บันทึกข้อมูลการจอง
$sql = "INSERT INTO bookings (user_id, room_id, booking_date, start_time, end_time) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iisss", $user_id, $room_id, $booking_date, $start_time, $end_time);

if ($stmt->execute()) {
    echo "จองห้องสำเร็จ!";
} else {
    echo "เกิดข้อผิดพลาด: " . $conn->error;
}
?>
