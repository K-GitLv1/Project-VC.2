<?php 
    include 'check_login.php';
    // include 'footer.php';
    include 'db/db_connection.php'; // เชื่อมต่อฐานข้อมูล

    // ดึงข้อมูลห้องประชุมจากฐานข้อมูล
    $sql = "SELECT * FROM rooms WHERE is_visible = 1"; // คำสั่ง SQL ดึงห้องประชุมที่สามารถแสดงได้
    $result = $conn->query($sql); // รันคำสั่ง SQL

    if ($result->num_rows > 0) {
        // มีข้อมูลห้องประชุม
        $rooms = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $rooms = [];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จองห้อง</title>
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/bk1.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@100..900&display=swap" rel="stylesheet">
    <script src="js/bk.js"></script>
</head>
<body>
<style>
        /* Calendar container */
.room-table {
    color:  rgb(255, 255, 255);
}
body {
    padding-bottom: 100px; /* เพิ่มช่องว่างที่ท้ายหน้า */
}
/* เพิ่มการตัดบรรทัดใน modal */
#roomDetails p {
    word-wrap: break-word; /* ตัดบรรทัดเมื่อข้อความยาวเกินพื้นที่ */
    white-space: normal;   /* ยอมให้ข้อความข้ามบรรทัดได้ */
}
.container {
    width: 1200px;
    margin: 0 auto;
    background-color: #4e54c8;
    color: #fff;
    padding: 20px;
    border-radius: 8px;
    margin-top: 200px;
}

.filter-options {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    margin-bottom: 20px;
}

.filter-options select,
.filter-options button {
    margin-left: 10px;
}

.room-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    table-layout: fixed; /* เพิ่มเพื่อให้ตารางมีความกว้างคงที่ */
}
.room-table th:first-child, .room-table td:first-child {
    width: 80%; /* ปรับความกว้างของคอลัมน์ซ้ายเป็น 70% */
}

.room-table th:last-child, .room-table td:last-child {
    width: 15%; /* ปรับความกว้างของคอลัมน์ขวา */
    text-align: center; /* จัดข้อความในหัวคอลัมน์ให้ตรงกลาง */
    vertical-align: middle; /* จัดเนื้อหาให้อยู่ตรงกลางในแนวตั้ง */
}

.room-table td:last-child {
    text-align: right; /* ปรับให้ปุ่มอยู่ชิดขวา */
}


.room-table th, .room-table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
    vertical-align: top; /* ปรับให้อัลไลน์เนื้อหาด้านบน */
    word-wrap: break-word; /* ตัดข้อความเมื่อเกินพื้นที่คอลัมน์ */
}

.room-table th {
    background-color: #6a71d7; /* เพิ่มสีพื้นหลังเพื่อให้ดูโดดเด่น */
    color: #fff;
    text-align: center; /* จัดให้ข้อความในหัวคอลัมน์อยู่ตรงกลาง */
}
.room-table td {
    text-align: left; /* ให้ข้อความในเซลล์คอลัมน์ "รายละเอียดห้อง" เรียงจากซ้าย */
}


.room-info {
    display: flex;
    flex-direction: column;
    max-width: 800px; /* จำกัดความกว้างคอลัมน์ */
    max-height: 5.6em; /* จำกัดความสูงให้ไม่เกิน 6 บรรทัด (1.4em ต่อบรรทัด) */
    overflow: hidden; /* ซ่อนข้อความที่เกิน */
    text-overflow: ellipsis; /* เพิ่ม ... สำหรับข้อความที่ถูกตัด */
    white-space: normal; /* อนุญาตให้ข้อความตัดบรรทัด */
    line-height: 1.4em; /* ระยะห่างระหว่างบรรทัด */
}


.room-name {
    font-weight: bold;
    font-size: 16px;
    margin-bottom: 5px;
}

.btn {
    padding: 8px 12px;
    margin-right: 5px;
    border: none;
    border-radius: 5px;
    color: #fff;
    cursor: pointer;
    display: inline-block;
}

.btn-book {
    background-color: #007bff;
}

.btn-detail {
    background-color: #ffa500;
}

.btn:hover {
    opacity: 0.9; /* เพิ่มเอฟเฟกต์ hover */
}

.modal {
    display: none; /* Hide modal by default */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    overflow: auto;
}

.modal-content {
    background-color: #fff;
    margin: 10% auto;
    padding: 20px;
    border-radius: 8px;
    width: 30%;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}

.close {
    float: right;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover {
    color: red;
}

#roomDetails {
    font-size: 16px;
    line-height: 1.5;
}

    </style>
<div class="container">
    <h2>ห้อง / รายการ</h2>
    
    <table class="room-table">
        <thead>
            <tr>
                <th>รายละเอียดห้อง</th>
                <th>การดำเนินการ</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rooms as $room): ?>
            <tr>
                <td>
                    <div class="room-info">
                        <span class="room-name"><?php echo htmlspecialchars($room['room_name']); ?></span>
                        <p><?php echo htmlspecialchars($room['description']); ?></p>
                    </div>
                </td>
                <td>
                    <button class="btn btn-book" onclick="openBookingModal('<?php echo $room['id']; ?>')">จองห้อง</button>
                    <button class="btn btn-detail" onclick="openModal(
                        '<?php echo htmlspecialchars($room['room_name']); ?>', 
                        '<?php echo htmlspecialchars($room['description']); ?>',
                        '<?php echo htmlspecialchars($room['capacity']); ?>',
                        '<?php echo htmlspecialchars($room['location']); ?>',
                        '<?php echo htmlspecialchars($room['room_number']); ?>',
                        '<?php echo htmlspecialchars($room['image']); ?>'
                    )">รายละเอียด</button>
                </td>
<!-- Modal สำหรับจองห้อง -->
<div id="bookingModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeBookingModal()">&times;</span>
        
        <h2>เพิ่ม การจอง</h2>
        <button type="reset" class="btn btn-clear">ล้างฟอร์ม</button>
        <form action="book_room.php" method="POST">
            <label>ชื่อห้อง:</label>
            <select name="room_id" id="room_id" required>
                <?php foreach ($rooms as $room): ?>
                    <option value="<?php echo $room['id']; ?>"><?php echo htmlspecialchars($room['room_name']); ?></option>
                <?php endforeach; ?>
            </select>
            
            <label>จำนวนผู้เข้าร่วม:</label>
            <input type="number" name="participants" required>
            <label>ชื่อผู้จอง:</label>
            <input type="text" name="booker_name" required>
            <label>โทรศัพท์:</label>
            <input type="tel" name="phone" required>
            <!-- วันที่เริ่มต้นและเวลาเริ่มต้นในบรรทัดเดียวกัน -->
<div style="display: flex; justify-content: space-between; align-items: center; gap: 10px;">
    <label>วันที่เริ่มต้น:</label>
    <label>เวลาเริ่มต้น:</label>
</div>
<div style="display: flex; justify-content: space-between; gap: 10px;">
    <input type="date" name="start_date" required>
    <input type="time" name="start_time" required>
</div>

<!-- วันที่สิ้นสุดและเวลาสิ้นสุดในบรรทัดเดียวกัน -->
<div style="display: flex; justify-content: space-between; align-items: center; gap: 10px; margin-top: 10px;">
    <label>วันที่สิ้นสุด:</label>
    <label>เวลาสิ้นสุด:</label>
</div>
<div style="display: flex; justify-content: space-between; gap: 10px;">
    <input type="date" name="end_date" required>
    <input type="time" name="end_time" required>
</div>


            <label>ใช้สำหรับ:</label>
            <select name="purpose">
                <option value="ประชุม">ประชุม</option>
                <option value="สัมมนา">สัมมนา</option>
                <option value="อบรม">อบรม</option>
            </select>
            <label>อุปกรณ์:</label>
            <div></div>
            <div class="cb">
                
            โปรเจคเตอร์ <input type="checkbox" name="equipment[]" value="โปรเจคเตอร์"> 
            &nbsp;ไมค์<input type="checkbox" name="equipment[]" value="ไมค์"> 
            </div>
            <div >
                
            
            </div>
            <label>อื่นๆ:</label>
            <textarea name="other_details"></textarea>
            <button type="submit" class="btn btn-save">บันทึก</button>
        </form>
    </div>
</div>


            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="roomModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>รายละเอียดห้องประชุม</h2>
        <div id="roomDetails">
            <!-- Room details will be injected here -->
        </div>
    </div>
</div>

<script>
document.querySelector('.btn-clear').addEventListener('click', function() {
    // ล้างข้อมูลในฟอร์ม
    document.querySelector('form').reset();

});


function openBookingModal(roomId) {
    document.getElementById("room_id").value = roomId;
    document.getElementById("bookingModal").style.display = "block";
}
function closeBookingModal() {
    document.getElementById("bookingModal").style.display = "none";
}
window.onclick = function(event) {
    let modal = document.getElementById("bookingModal");
    if (event.target === modal) {
        modal.style.display = "none";
    }
}
document.addEventListener("DOMContentLoaded", function () {
    // ฟังก์ชันตั้งค่าวันที่และเวลาเป็นค่าปัจจุบัน
    function setDefaultDateTime() {
        let now = new Date();
        
        // ตั้งค่าฟอร์แมตให้เป็น YYYY-MM-DD สำหรับ input type="date"
        let dateStr = now.toISOString().split("T")[0];

        // ตั้งค่าฟอร์แมตให้เป็น HH:MM สำหรับ input type="time"
        let timeStr = now.toTimeString().split(" ")[0].slice(0, 5);

        // กำหนดค่าลงใน input
        document.querySelector('input[name="start_date"]').value = dateStr;
        document.querySelector('input[name="end_date"]').value = dateStr;
        document.querySelector('input[name="start_time"]').value = timeStr;
        document.querySelector('input[name="end_time"]').value = timeStr;
    }

    // เรียกใช้งานฟังก์ชันเมื่อเปิด Modal
    document.querySelector(".btn-book").addEventListener("click", setDefaultDateTime);
});
</script>
</body>
</html>

