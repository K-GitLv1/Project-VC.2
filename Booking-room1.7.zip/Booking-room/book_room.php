<?php
include 'db/db_connection.php';
session_start();

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือไม่
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('กรุณาเข้าสู่ระบบก่อนทำการจอง'); window.location.href='login.php';</script>";
    exit();
}

// รับค่าจากฟอร์ม
$user_id = $_SESSION['user_id'];
$room_id = $_POST['room_id'];
$participants = $_POST['participants'];
$booker_name = $_POST['booker_name'];
$phone = $_POST['phone'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];
$purpose = $_POST['purpose'];
$equipment = isset($_POST['equipment']) ? implode(", ", $_POST['equipment']) : '';
$other_details = $_POST['other_details'];

// ตรวจสอบการจองซ้อน
$check_sql = "SELECT * FROM bookings WHERE room_id = ? 
              AND ((start_date <= ? AND end_date >= ?) 
              AND (start_time < ? AND end_time > ?))";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param("issss", $room_id, $end_date, $start_date, $end_time, $start_time);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<script>alert('ห้องนี้ถูกจองในช่วงเวลาที่เลือกแล้ว กรุณาเลือกเวลาอื่น'); window.location.href='bk.php';</script>";
    exit();
}

// บันทึกข้อมูลการจอง
$sql = "INSERT INTO bookings (user_id, room_id, participants, booker_name, phone, start_date, end_date, start_time, end_time, purpose, equipment, other_details) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiisssssssss", $user_id, $room_id, $participants, $booker_name, $phone, $start_date, $end_date, $start_time, $end_time, $purpose, $equipment, $other_details);

if ($stmt->execute()) {
    echo "<script>alert('จองห้องสำเร็จ!'); window.location.href='bk.php';</script>";
} else {
    echo "<script>alert('เกิดข้อผิดพลาด: " . $stmt->error . "'); window.location.href='bk.php';</script>";
}

// ปิดการเชื่อมต่อ
$stmt->close();
$conn->close();
?>
