-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2025 at 04:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bkx2`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `room_id` int(11) NOT NULL,
  `participants` int(11) NOT NULL,
  `booker_name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `equipment` varchar(255) DEFAULT NULL,
  `other_details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_confirmed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `room_id`, `participants`, `booker_name`, `phone`, `start_date`, `end_date`, `start_time`, `end_time`, `purpose`, `equipment`, `other_details`, `created_at`, `is_confirmed`) VALUES
(4, 6, 34, 123, 'tester', '123', '2025-02-02', '2025-02-03', '02:08:00', '02:08:00', 'ประชุม', '', '', '2025-02-01 19:08:49', 1),
(5, 6, 34, 123, 'tester', '123', '2025-02-02', '2025-02-03', '02:09:00', '02:09:00', 'ประชุม', '', '', '2025-02-01 19:09:50', 0),
(6, 6, 34, 123, 'tester', '123', '2025-02-02', '2025-02-02', '02:13:00', '02:13:00', 'ประชุม', '', '', '2025-02-01 19:13:59', 0),
(7, 6, 34, 123, 'tester', '123', '2025-02-03', '2025-02-04', '14:03:00', '14:04:00', 'ประชุม', 'โปรเจคเตอร์', '', '2025-02-03 07:03:59', 0),
(8, 6, 34, 123, 'tester', '123', '2025-02-03', '2025-02-03', '19:52:00', '19:53:00', 'ประชุม', '', '', '2025-02-03 12:52:29', 0),
(9, 6, 34, 123, 'tester', '123', '2025-02-03', '2025-02-04', '19:52:00', '19:52:00', 'ประชุม', '', '', '2025-02-03 12:52:46', 0),
(10, 6, 36, 123, 'tester', '123', '2025-02-03', '2025-02-04', '19:53:00', '19:53:00', 'ประชุม', '', '', '2025-02-03 12:53:50', 0),
(11, 6, 37, 12, '1', '123', '2025-02-03', '2025-02-03', '19:53:00', '19:53:00', 'ประชุม', '', '', '2025-02-03 12:54:13', 0),
(12, 6, 34, 213, '1', '123', '2025-02-03', '2025-02-04', '19:55:00', '19:55:00', 'ประชุม', '', '', '2025-02-03 12:55:28', 0),
(13, 6, 36, 123, 'tester', '123', '2025-02-03', '2025-02-04', '19:55:00', '19:55:00', 'ประชุม', '', '', '2025-02-03 12:55:43', 0),
(14, 6, 34, 123, 'tester', '123', '2025-02-03', '2025-02-05', '19:56:00', '19:56:00', 'ประชุม', '', '', '2025-02-03 12:55:59', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_name` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `room_number` varchar(50) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_visible` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_name`, `color`, `description`, `location`, `room_number`, `capacity`, `image`, `created_at`, `is_visible`) VALUES
(34, '123', NULL, 'test', 'test', '123', 123, 'uploads/1738214687_6518561685168.jpg', '2025-01-28 16:55:01', 1),
(36, 'ะำหะ', NULL, '', '', '', 0, 'uploads/1738083714_11.jpg', '2025-01-28 17:01:11', 1),
(37, 'test', NULL, '', '', '', 0, 'uploads/1738083821_11.jpg', '2025-01-28 17:02:49', 1),
(38, 'test', NULL, 'test', 'test', '123', 123, 'uploads/1738083858_omjncj2deLo4WCZNavo-o.jpg', '2025-01-28 17:03:59', 1),
(42, 'tes', NULL, '', '', '', 0, 'uploads/1738084655_11.jpg', '2025-01-28 17:17:35', 1),
(44, 'test', NULL, 'test', 'test', '123', 123, 'uploads/1738085555_11.jpg', '2025-01-28 17:32:35', 1),
(52, 'ะำหะ', NULL, '', '', '', 0, NULL, '2025-01-28 17:48:47', 1),
(53, 'ะำหะ', NULL, '', '', '', 0, NULL, '2025-01-28 17:48:50', 1),
(54, 'ะำหะ', NULL, '', '', '', 0, NULL, '2025-01-28 17:48:53', 1),
(55, 'ะหำะ', NULL, '', '', '', 0, NULL, '2025-01-28 17:48:56', 1),
(56, 'ะำหะ', NULL, '', '', '', 0, NULL, '2025-01-28 17:48:59', 1),
(57, 'test', NULL, '', '', '', 0, NULL, '2025-01-28 17:49:02', 1),
(58, 'test', NULL, '', '', '', 0, NULL, '2025-01-28 17:49:06', 1),
(59, 'test', NULL, '', '', '', 0, 'uploads/1738214860_11.jpg', '2025-01-28 17:49:09', 1),
(64, 'ะำห', NULL, '', '', '', 0, NULL, '2025-01-30 05:27:45', 1),
(65, 'tess', NULL, '', '', '', 0, 'uploads/1738214875_11.jpg', '2025-01-30 05:27:55', 1),
(66, 'test', NULL, '', '', '', 0, NULL, '2025-02-01 16:21:12', 1),
(67, 'test', NULL, '', '', 'UDTC-067', 0, NULL, '2025-02-01 16:23:47', 1),
(68, 'test', NULL, '', '', 'UDTC-068', 0, NULL, '2025-02-01 16:24:09', 1),
(69, 'test', NULL, '', '', 'UDTC-069', 0, NULL, '2025-02-01 16:26:45', 1),
(70, 'testetset', NULL, '', '', 'UDTC-070', 0, 'uploads/1738430021_11.jpg', '2025-02-01 16:26:58', 1),
(71, 'พพพ', NULL, '', '', '', 0, NULL, '2025-02-01 16:28:32', 1),
(72, 'test', NULL, '', '', '', 0, 'uploads/1738429702_6518561685168.jpg', '2025-02-01 16:31:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'test', '$2y$10$woQghDEDNIMqoKXX6P84gOia3Yr0MJA0epa3ZB/0/U2J9Cyxa6usa', '2024-10-27 16:16:16'),
(2, 'test2', '$2y$10$PRHUMrFheweD57Sa.anxm.LrZe0a48FuvzqrG/H1PLvZejeFUlT9W', '2024-10-27 16:20:32'),
(3, 'test3', '$2y$10$wLWa2wla2OrBOLFPRrNjGOjAENqwgIdgZi1UeoD1WyKqu/eL9tsCa', '2024-10-30 13:55:20'),
(6, 'admin', '$2y$10$Rl5jn/4maFi5kq.rrztafew.bQCAWrOXLQaBj1vwusnJo9P8vslNK', '2024-12-06 10:42:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
