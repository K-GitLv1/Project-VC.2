<?php
// เชื่อมต่อฐานข้อมูล
include 'db/db_connection.php';

// ตรวจสอบว่าได้ส่งค่า 'id' มาหรือไม่
if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);  // ป้องกัน SQL Injection

    // ลบข้อมูลการจองจากฐานข้อมูล
    $sql = "DELETE FROM bookings WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $booking_id);

    if ($stmt->execute()) {
        // หากลบสำเร็จ
        header("Location: manage_bookings.php?status=success");
    } else {
        // หากเกิดข้อผิดพลาดในการลบ
        header("Location: manage_bookings.php?status=error");
    }

    $stmt->close();
} else {
    // หากไม่มีการส่ง 'id' มา
    header("Location: manage_bookings.php?status=error");
}

$conn->close();
?>
