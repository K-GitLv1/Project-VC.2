<?php
include 'db/db_connection.php'; // เชื่อมต่อกับฐานข้อมูล

$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);

$events = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = array(
            'title' => $row['purpose'],
            'start' => $row['start_date'] . 'T' . $row['start_time'],
            'end' => $row['end_date'] . 'T' . $row['end_time'],
            'description' => $row['other_details'],
            'is_confirmed' => $row['is_confirmed'],  // เพิ่มข้อมูลการยืนยัน
            'className' => $row['is_confirmed'] == 1 ? 'confirmed' : 'unconfirmed'  // เพิ่มคลาส
        );
    }
}

// ส่งข้อมูลในรูปแบบ JSON
echo json_encode($events);

$conn->close();
?>
